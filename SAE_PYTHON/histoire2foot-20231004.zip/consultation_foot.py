import histoire2foot

# Ici vos fonctions dédiées aux interactions

# ici votre programme principal
def programme_principal():
    ...
